"""Replay frozen scanner on 1000 exchange sessions, plus 44 warm-up sessions."""
import sys,json,hashlib,zipfile,re,collections,math
from pathlib import Path
import numpy as np
import pandas as pd
import exchange_calendars as xc
import frozen_engine as engine
ROOT=Path(__file__).parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
sessions=xc.get_calendar('XSHG').sessions_in_range('2021-01-01','2026-10-20')[-1044:]
dates=[d.date().isoformat() for d in sessions]
date_int=np.array([int(x.replace('-','')) for x in dates],dtype=np.uint32)
cutoff=44
dtype=np.dtype([('date','<u4'),('open','<u4'),('high','<u4'),('low','<u4'),('close','<u4'),('amount','<f4'),('volume','<u4'),('reserved','<u4')])
parse_issues=[]
if '--matrix' in sys.argv:
    cache=np.load(ROOT/'data'/'tdx_1044_session_matrices.npz')
    assert cache['dates'].tolist()==dates
    symbols=cache['symbols'].tolist();n=len(symbols);t=len(dates)
    arrays={k:cache[k] for k in ('open','high','low','close','amount','volume')}
else:
    series={};parse_issues=[]
    for market in ('sh','sz'):
        with zipfile.ZipFile(ROOT/'data'/f'{market}lday.zip') as z:
            names=[n for n in z.namelist() if re.fullmatch(r'(sh(?:60|68)\d{4}|sz(?:00|30)\d{4})\.day',Path(n).name.lower())]
            print('ZIP',market,len(names),flush=True)
            for n in names:
                symbol=Path(n).stem.lower();blob=z.read(n)
                if len(blob)%32:parse_issues.append([symbol,'record_length']);continue
                a=np.frombuffer(blob,dtype=dtype)
                a=a[(a['date']>=date_int[0]) & (a['date']<=date_int[-1])]
                if not len(a):continue
                if len(np.unique(a['date']))!=len(a):parse_issues.append([symbol,'duplicate_dates']);continue
                if symbol in series:raise ValueError('Duplicate ZIP symbol '+symbol)
                series[symbol]=a.copy()
    symbols=sorted(series);n=len(symbols);t=len(dates)
    print('UNIVERSE',n,'DATES',t,flush=True)
    arrays={key:np.full((t,n),np.nan) for key in ('open','high','low','close','amount','volume')}
    for j,symbol in enumerate(symbols):
        a=series[symbol];ix=np.searchsorted(date_int,a['date']);good=(ix<t)
        good &= date_int[np.minimum(ix,t-1)]==a['date']
        for key,m in arrays.items():m[ix[good],j]=a[key][good]/(100 if key in ('open','high','low','close') else 1)
    del series
O,H,L,C,A,V=[arrays[k] for k in ('open','high','low','close','amount','volume')]
exists=np.isfinite(C)
valid=exists & (O>0)&(C>0)&(L>0)&(H>=np.maximum(O,C))&(L<=np.minimum(O,C))&(H>=L)&np.isfinite(A)&(A>=0)&np.isfinite(V)&(V>=0)
boards=np.array([engine.board_of(s) or 'OTHER' for s in symbols])
masks={g:boards==g for g in ('CY','KC')}
rets=np.full_like(C,np.nan);rets[1:]=(C[1:]/C[:-1]-1)*100
matched=valid.copy();matched[1:] &= valid[:-1];matched[0]=False
outlier=matched & (np.abs(rets)>engine.PRICE_OUTLIER*100)

def stats(i,mask):
    members=mask&valid[i];raw=members&matched[i]
    bad=raw&outlier[i];ok=raw&~outlier[i]
    r=rets[i,ok]
    if not len(r):return None
    amt=A[i,ok];lead=r>=7;total=float(amt.sum())
    return dict(n=len(r),members_n=int(members.sum()),matched_raw=int(raw.sum()),outlier_count=int(bad.sum()),
        outlier_symbols=[symbols[j] for j in np.flatnonzero(bad)[:40]],outlier_share=float(bad.sum()/max(1,raw.sum())),
        breadth2=float(np.mean(r>=2)),breadth_up=float(np.mean(r>0)),leader7=float(np.mean(lead)),leader_count=int(lead.sum()),
        leader_amount_share=float(amt[lead].sum()/total) if total else None,amount=total,eq_return=float(r.mean()),
        median_return=float(np.quantile(r,.5)),p90_return=float(np.quantile(r,.9)),p10_return=float(np.quantile(r,.1)),
        coverage=float(len(r)/max(1,members.sum())))

days=[];accepted=[];feature_rows=[]
for i,day in enumerate(dates):
    raw=dict(date=day,count=int(valid[i].sum()),invalid=int((exists[i]&~valid[i]).sum()),duplicates=0,
             board_counts={g:int((valid[i]&m).sum()) for g,m in masks.items()})
    reasons=engine.daily_quality(raw,accepted)
    one=dict(raw,global_ok=not reasons,quality_reasons=reasons,groups={})
    if one['global_ok']:accepted.append(raw)
    market=stats(i,np.ones(n,dtype=bool)) if i and one['global_ok'] and days[i-1]['global_ok'] else None
    for g,mask in masks.items():
        base=dict(id=g,name={'CY':'创业板全板','KC':'科创板全板'}[g],kind='风格池')
        if not one['global_ok']:base.update(health=reasons,status='BLOCKED')
        elif not i or not days[i-1]['global_ok']:base.update(health=['无连续合格前收盘价'],status='BLOCKED')
        else:
            st=stats(i,mask);health=engine.basic_health(st,g)
            base.update(health=health,stats=st,status='BLOCKED' if health else 'OK',raw_healthy=not health)
            if not health:
                trailing=[days[j]['groups'][g] for j in range(max(0,i-5),i)]
                st['amount_ratio5']=st['amount']/engine.avg(x['stats']['amount'] for x in trailing) if len(trailing)==5 and all(x.get('raw_healthy') for x in trailing) and engine.avg(x['stats']['amount'] for x in trailing) else None
                prev=days[i-1]['groups'][g]
                if prev.get('raw_healthy') and i>=engine.MIN_HISTORY:
                    back=[days[j]['groups'][g] for j in range(i-20,i)]
                    if all(x.get('raw_healthy') for x in back) and st['amount_ratio5'] is not None:base.update(engine.score_state(st,prev['stats'],back,market))
                    else:base.update(status='WARMUP',health=['20个连续有效历史观测不足'])
                else:base.update(status='WARMUP',health=['至少需要20个完整历史比较日'])
        one['groups'][g]=base
        feature_rows.append(dict(date=day,board=g,status=base['status'],stage=base.get('stage'),score=base.get('score'),health=' / '.join(base.get('health',[])),**{k:v for k,v in (base.get('stats') or {}).items() if k not in ('outlier_symbols',)}))
    days.append(one)
    if i%200==0:print('FEATURES',i,day,raw['count'],flush=True)

def forward(i,g,h):
    if i+h>=t:return dict(status='unmatured')
    seq=days[i:i+h+1]
    if any(not d['global_ok'] for d in seq):return dict(status='blocked',why='持有窗口全市场质量失败')
    if any(not d['groups'][g].get('raw_healthy') for d in seq[1:]):return dict(status='blocked',why='持有窗口板块质量失败')
    members=masks[g]&valid[i];ok=members.copy()
    for j in range(i+1,i+h+1):ok &= valid[j] & valid[j-1] & ~outlier[j]
    ok &= np.abs((O[i+1]/C[i]-1)*100)<=engine.PRICE_OUTLIER*100
    if ok.sum()/max(1,members.sum())<.95:return dict(status='blocked',why='价格留存不足95%')
    rr=(C[i+h,ok]/O[i+1,ok]-1)*100
    net=float(rr.mean()-.2)
    # Conservative execution stress: positive one-price entry => cash; negative
    # one-price exit => unresolved, no fictitious successful liquidation.
    buyflat=(H[i+1,ok]==L[i+1,ok])&(O[i+1,ok]>C[i,ok])
    sellflat=(H[i+h,ok]==L[i+h,ok])&(C[i+h,ok]<C[i+h-1,ok])
    stress=None if np.any(sellflat&~buyflat) else float(np.where(buyflat,0,rr-.2).mean())
    nav=np.nanmean(C[i+1:i+h+1,ok]/O[i+1,ok],axis=1)
    mae=float(min(0,nav.min()-1)*100)
    return dict(status='ok',gross_pct=float(rr.mean()),net_pct=net,matched=int(ok.sum()),
        excluded_unverified_price=int(members.sum()-ok.sum()),entry_date=dates[i+1],exit_date=dates[i+h],
        close_path_mae_pct=mae,entry_unfilled=int(buyflat.sum()),exit_unresolved=int((sellflat&~buyflat).sum()),execution_stress_net_pct=stress)

events=[];last_signal={}
for i in range(cutoff,t):
    for g,base in days[i]['groups'].items():
        if base['status']!='OK' or base.get('stage') not in ('R1c','R2a','R2b'):continue
        if i-last_signal.get(g,-100)<20:continue
        last_signal[g]=i
        e=dict(i=i,date=dates[i],id=g,name=base['name'],stage=base['stage'],score=base['score'],period='前700日' if i-cutoff<700 else '后300日')
        for h in (5,10,20):e[f'hold{h}']=forward(i,g,h)
        events.append(e)

def summary(ev):
    result={}
    for h in (5,10,20):
        a=[e[f'hold{h}'] for e in ev];good=[x for x in a if x['status']=='ok'];r=np.array([x['net_pct'] for x in good])
        result[str(h)]=dict(signals=len(ev),matured=len(r),blocked=sum(x['status']=='blocked' for x in a),unmatured=sum(x['status']=='unmatured' for x in a),
            win_rate=float(np.mean(r>0)) if len(r) else None,mean_net_pct=float(r.mean()) if len(r) else None,median_net_pct=float(np.median(r)) if len(r) else None,
            worst_net_pct=float(r.min()) if len(r) else None,best_net_pct=float(r.max()) if len(r) else None,
            mean_close_path_mae_pct=float(np.mean([x['close_path_mae_pct'] for x in good])) if good else None,
            execution_stress_eligible=sum(x['execution_stress_net_pct'] is not None for x in good),
            execution_stress_mean_pct=engine.avg(x['execution_stress_net_pct'] for x in good))
    return result

# Check vectorized statistics against the unchanged scalar engine on real days.
parity=[]
for i in (44,244,544,844,1043):
    def point(day,j):return {key:float(m[day,j]) for key,m in arrays.items()}
    today={'stocks':{s:point(i,j) for j,s in enumerate(symbols) if valid[i,j]}}
    yesterday={'stocks':{s:point(i-1,j) for j,s in enumerate(symbols) if valid[i-1,j]}}
    for g,mask in masks.items():
        members={s for j,s in enumerate(symbols) if mask[j] and valid[i,j]}
        expected=engine.universe_stats(today,yesterday,members);actual=stats(i,mask)
        if expected is None or actual is None:continue
        for key in ('n','outlier_count','breadth2','leader7','amount','eq_return','coverage'):
            if not np.isclose(expected[key],actual[key],rtol=1e-10,atol=1e-8):raise AssertionError((dates[i],g,key,expected[key],actual[key]))
        parity.append({'date':dates[i],'board':g,'passed':True})

baseline={}
for g in masks:
    entries=[]
    for i in range(cutoff,t):
        if days[i]['groups'][g]['status']!='OK':continue
        e={f'hold{h}':forward(i,g,h) for h in (5,10,20)}
        entries.append(e)
    baseline[g]=summary(entries)

period_days=days[cutoff:]
quality=[{k:d[k] for k in ('date','count','board_counts','global_ok','quality_reasons')} for d in period_days]
coverage={g:dict(collections.Counter(d['groups'][g]['status'] for d in period_days)) for g in masks}
stages={g:dict(collections.Counter(d['groups'][g].get('stage','未计算') for d in period_days)) for g in masks}
report=dict(schema=1,asof=dates[-1],start=dates[cutoff],requested_sessions=1000,actual_sessions=len(period_days),warmup_sessions=cutoff,
    source='通达信官方沪深日线整包（未复权）',source_manifest=json.loads((ROOT/'data'/'tdx_manifest.json').read_text()),
    frozen_engine_sha256=hashlib.sha256((ROOT/'frozen_engine.py').read_bytes()).hexdigest(),parse_issues=parse_issues,
    universe_symbols=n,quality_passed=sum(d['global_ok'] for d in period_days),coverage=coverage,stage_counts=stages,
    summary={g:summary([e for e in events if e['id']==g]) for g in masks},
    baseline=baseline,scalar_engine_parity=parity,
    diagnostics={'legacy_quantile_bug':'原引擎的分位数在排序位置恰为整数时错误返回0；本报告采用numpy标准线性分位数。该字段不参与评分或阶段判定，未改变任何信号阈值。'},
    by_stage={g:{s:summary([e for e in events if e['id']==g and e['stage']==s]) for s in ('R1c','R2a','R2b')} for g in masks},
    by_period={p:{g:summary([e for e in events if e['id']==g and e['period']==p]) for g in masks} for p in ('前700日','后300日')},
    events=events,quality=quality,
    latest_groups=list(days[-1]['groups'].values()),
    caveats=['仅创业板全板与科创板全板风格池，缺少历史行业PIT名单，未声称完成行业点火回测',
    '现存整包的退市股历史完整性未经验证，可能有幸存者偏差','未复权股价；大于23%跳价按冻结规则隔离，小额分红影响未完全剔除',
    '次交易日开盘到第5/10/20个后续交易日收盘的个股等权执行代理，扣往返0.20个百分点，不是ETF实盘收益',
    '一字涨停入场记现金、一字跌停退出记未解决，ST历史及真实队列无法完整还原',
    '同一板块信号至少间隔20日；两板块不是独立样本','规则于2026-10-20已确定，前700/后300只是时段稳定性诊断，不是真正事前样本外验证',
    '不得将数据或执行条件失败的事件当成成功交易；未成熟事件不计胜负'])
# Separate diagnostic: R2-only observations cannot be suppressed by an earlier
# R1c event. This is reported separately, never substituted into the frozen run.
r2events=[];last_r2={}
for i in range(cutoff,t):
    for g,base in days[i]['groups'].items():
        if base['status']!='OK' or base.get('stage') not in ('R2a','R2b'):continue
        if i-last_r2.get(g,-100)<20:continue
        last_r2[g]=i
        e=dict(date=dates[i],id=g,stage=base['stage'],score=base['score'])
        for h in (5,10,20):e[f'hold{h}']=forward(i,g,h)
        r2events.append(e)
report['r2_only_diagnostic']={g:summary([e for e in r2events if e['id']==g]) for g in masks}
report['r2_only_events']=r2events
report['outlier_sensitivity']={g:{str(h):dict(without_best_mean_pct=engine.avg(sorted([e[f'hold{h}']['net_pct'] for e in events if e['id']==g and e[f'hold{h}']['status']=='ok'])[:-1])) for h in (5,10,20)} for g in masks}
live_path=ROOT/'data'/'live_2026_10_20.csv'
if live_path.exists():
    live=pd.read_csv(live_path,header=None,names=['symbol','date','open','close','high','low','volume','amount']).set_index('symbol')
    pairs=[(j,s) for j,s in enumerate(symbols) if valid[-1,j] and s in live.index]
    diffs=[abs(C[-1,j]-float(live.loc[s,'close'])) for j,s in pairs]
    report['live_crosscheck']=dict(matched=len(pairs),close_equal_cent=int(sum(d<=.011 for d in diffs)),max_close_difference=max(diffs),
        source='Tencent live archive 2026-10-20 compared with official TDX archive')
(OUT/'backtest1000.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
def public_group(g):
    x=g.copy()
    if x.get('stats'):x['stats']={k:(engine.rounded(v,5) if isinstance(v,float) else v) for k,v in x['stats'].items()}
    return x
scan=dict(schema=2,engine_version=engine.VERSION,generated_utc=pd.Timestamp.now(tz='UTC').isoformat(),asof=dates[-1],
    source=dict(name='通达信官方沪深日线整包：1000交易日历史回放',url='https://www.tdx.com.cn/products/data/data/vipdoc/shlday.zip',
                calendar=True,pit_loaded=False,calendar_source='exchange_calendars/XSHG',scope_note='创业板全板 / 科创板全板；未包含历史行业PIT成分'),
    quality=[dict(date=d['date'],passed=d['global_ok'],n=d['count'],board_counts=d['board_counts'],reasons=d['quality_reasons']) for d in period_days],
    groups=[public_group(g) for g in days[-1]['groups'].values()],
    daily_groups={d['date']:[public_group(g) for g in d['groups'].values()] for d in period_days},
    series={g:[dict(date=d['date'],status=d['groups'][g]['status'],stage=d['groups'][g].get('stage'),score=d['groups'][g].get('score'),
                   **{k:engine.rounded((d['groups'][g].get('stats') or {}).get(k),5) for k in ('breadth2','leader7','amount_ratio5','eq_return')}) for d in period_days] for g in masks},
    events=[{k:v for k,v in e.items() if k not in ('i','period')} for e in events],
    rules=dict(warmup_days=engine.MIN_HISTORY,outlier_abs_change_pct=23,board_outlier_threshold=.0075,event_lock_days=20,next_open_proxy=True,research_cost_pct_points=.20),
    caveats=report['caveats'])
(OUT/'scan_data.json').write_text(json.dumps(scan,ensure_ascii=False,separators=(',',':'),allow_nan=False))
bootstrap=ROOT/'bootstrap_archive';bootstrap.mkdir(exist_ok=True)
for i in range(t-23,t-1):
    # 22 preceding sessions warm up the next scheduled live replay; retain the
    # already-captured live snapshot for today rather than overwrite its identity.
    rows=[]
    for j in np.flatnonzero(valid[i]):
        rows.append([symbols[j],dates[i],O[i,j],C[i,j],H[i,j],L[i,j],V[i,j]/100,A[i,j]])
    import csv
    path=bootstrap/f'stock_price_{dates[i].replace("-","_")}.csv'
    with path.open('w',newline='') as f:csv.writer(f).writerows(rows)
    path.with_suffix('.provenance.json').write_text(json.dumps(dict(source='TDX official historical daily archive',trade_date=dates[i],
        retrieved_date='2026-10-20',volume_unit='lots (TDX shares / 100)',amount_unit='CNY',historical_backfill=True,
        note='今日下载的历史日线，不冒充当日实时归档；未复权，不包含行业PIT'),ensure_ascii=False,indent=2))
pd.DataFrame(feature_rows).to_csv(OUT/'daily_features.csv',index=False)
pd.DataFrame([dict(date=e['date'],board=e['id'],stage=e['stage'],score=e['score'],horizon=h,**e[f'hold{h}']) for e in events for h in (5,10,20)]).to_csv(OUT/'events.csv',index=False)
pd.DataFrame([dict(date=d['date'],global_ok=d['global_ok'],count=d['count'],CY=d['board_counts']['CY'],KC=d['board_counts']['KC'],reasons=' / '.join(d['quality_reasons'])) for d in period_days]).to_csv(OUT/'quality.csv',index=False)
if '--matrix' not in sys.argv:np.savez_compressed(ROOT/'data'/'tdx_1044_session_matrices.npz',dates=np.array(dates),symbols=np.array(symbols),**arrays)
print('RESULT',json.dumps({k:report[k] for k in ('start','asof','actual_sessions','quality_passed','coverage','summary')},ensure_ascii=False),flush=True)

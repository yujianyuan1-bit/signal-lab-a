猪皮信号1000交易日回测（2026-10-20）
窗口：2022-08-30至2026-10-20，另44交易日预热。
主规则、收益代理、事件逐条记录与限制见backtest1000.html与backtest1000.json。
运行：python -m pip install numpy pandas exchange-calendars matplotlib
完整原始ZIP在data/shlday.zip、data/szlday.zip；原始文件版本哈希见data/tdx_manifest.json。
已有同版本历史矩阵时运行 python run_backtest.py --matrix，可无需重新下载原始ZIP。
请保留历史矩阵文件data/tdx_1044_session_matrices.npz及data/tdx_manifest.json。
不要用未来更新版本的价格包冒充这次原始输入。当前名单或行业归属不可倒填历史。

import json,html,zipfile,hashlib,shutil
from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).parent;O=R/'results'
r=json.loads((O/'backtest1000.json').read_text());names={'CY':'创业板全板','KC':'科创板全板'}
def pct(x):return '—' if x is None else f'{x:+.2f}%'
def rate(x):return '—' if x is None else f'{x:.1%}'
def table(headers,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def result_rows(container):
 return [[names[g],h,x['matured'],rate(x['win_rate']),pct(x['mean_net_pct']),pct(x['median_net_pct']),pct(x['worst_net_pct']),f"{x['blocked']} / {x['unmatured']}"] for g,hs in container.items() for h,x in hs.items()]
headers=['范围','持有交易日','有效事件','净收益>0比例','平均净收益','中位净收益','最差单次','隔离 / 未到期']
main=table(headers,result_rows(r['summary']));r2=table(headers,result_rows(r['r2_only_diagnostic']))
stage_rows=[]
for g,stages in r['by_stage'].items():
 for stage,hs in stages.items():
  stage_rows.append([names[g],stage]+[f"{pct(hs[h]['mean_net_pct'])}（n={hs[h]['matured']}）" for h in ('5','10','20')])
stages=table(['范围','状态','5日均值','10日均值','20日均值'],stage_rows)
baseline=table(['范围','天数','信号均值','普通时点均值','均值差（百分点）','删除最好一次后的信号均值'],[[names[g],h,pct(x['mean_net_pct']),pct(r['baseline'][g][h]['mean_net_pct']),f"{x['mean_net_pct']-r['baseline'][g][h]['mean_net_pct']:+.2f}",pct(r['outlier_sensitivity'][g][h]['without_best_mean_pct'])] for g,hs in r['summary'].items() for h,x in hs.items()])
period=table(['时段','范围','5日平均','10日平均','20日平均','20日有效事件'],[[p,names[g],*[pct(hs[h]['mean_net_pct']) for h in ('5','10','20')],hs['20']['matured']] for p,gs in r['by_period'].items() for g,hs in gs.items()])
today=table(['范围','状态 / 分数','涨幅≥2%','涨幅≥7%','上涨占比','成交额 / 前5日'],[[g['name'],g['stage']+' / '+str(g['score']),rate(g['stats']['breadth2']),rate(g['stats']['leader7']),rate(g['stats']['breadth_up']),f"{g['stats']['amount_ratio5']:.2f}x"] for g in r['latest_groups']])
coverage=table(['范围','可评分日','预热日','隔离日','观察事件'],[[names[g],x.get('OK',0),x.get('WARMUP',0),x.get('BLOCKED',0),r['summary'][g]['5']['signals']] for g,x in r['coverage'].items()])
df=pd.read_csv(O/'daily_features.csv');df=df[df.date>=r['start']]
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(12,3.2),facecolor='#0e192b');ax.set_facecolor('#0e192b')
for g,color in [('CY','#5ce1ba'),('KC','#9ba9ff')]:
 d=df[df.board==g];ax.plot(pd.to_datetime(d.date),d.score,label=g,color=color,lw=.9,alpha=.85)
ax.set_ylim(0,100);ax.set_ylabel('Score',color='#b8c7dc');ax.tick_params(colors='#b8c7dc');ax.grid(alpha=.10);ax.legend(facecolor='#122139',labelcolor='white',loc='upper left')
for s in ax.spines.values():s.set_color('#2b3c53')
fig.tight_layout();fig.savefig(O/'score_history.svg',facecolor=fig.get_facecolor());plt.close(fig)
svg=(O/'score_history.svg').read_text();svg=svg[svg.index('<svg'):]
event_data=json.dumps(r['events'],ensure_ascii=False).replace('</','<\\/')
page='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>猪皮信号 · 1000交易日回测</title><style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#080e19;color:#e9f0fb;font:15px/1.7 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}main{max-width:1200px;margin:auto;padding:28px 22px 70px}a{color:#60dfbb}.eyebrow{color:#60dfbb;letter-spacing:.14em;font-size:12px}h1{font-size:clamp(29px,5vw,46px);margin:12px 0;line-height:1.2}h2{font-size:22px;margin:36px 0 8px}p{color:#b3c3d8}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.card,.panel{background:#101c2f;border:1px solid #2a3b53;border-radius:15px;padding:19px}.card b{font-size:31px;display:block}.small{font-size:12px;color:#9cb0ca}.warn{background:#342719;border:1px solid #7c5936;border-radius:13px;padding:16px;color:#f5d19b;margin:22px 0}.scroll{overflow:auto;border:1px solid #2a3b53;border-radius:13px}table{border-collapse:collapse;width:100%;font-size:13px;white-space:nowrap}th,td{text-align:right;border-bottom:1px solid #22334c;padding:11px 13px}th{background:#15263f;color:#a8bdd7}th:first-child,td:first-child{text-align:left}tr:last-child td{border:0}select{background:#172942;border:1px solid #38516e;color:white;border-radius:8px;padding:9px;margin:7px}svg{width:100%;height:auto}li{color:#aebfd4;margin:7px 0}.links{display:flex;gap:18px;flex-wrap:wrap}code{overflow-wrap:anywhere;color:#a8c5de;font-size:12px}details{margin:20px 0}.positive{color:#60dfbb}@media(max-width:700px){main{padding:20px 14px 50px}.cards{grid-template-columns:repeat(2,1fr)}.card{padding:14px}.card b{font-size:25px}}
</style></head><body><main><div class="links"><a href="./scanner.html">← 返回扫描页</a><a href="./backtest1000.json">完整结果 JSON</a><a href="./backtest1000_source.zip">复现代码与明细 ZIP</a></div><p class="eyebrow">ZHUPI SIGNAL / FROZEN-RULE REPLAY</p><h1>1000 个交易日，真实历史回放</h1><p>2022-08-30 — 2026-10-20 · 另加44天预热 · 次日开盘执行代理 · 往返成本0.20个百分点</p>
<div class="cards"><div class="card"><span class="small">实际回放</span><b>1000 天</b><span class="small">全市场截面质控全部通过</span></div><div class="card"><span class="small">历史窗口出现过的股票代码</span><b>5,381</b><span class="small">退市历史完整性仍待独立核验</span></div><div class="card"><span class="small">创业板可评分 / 事件</span><b>946 / 23</b><span class="small">其余为预热或隔离</span></div><div class="card"><span class="small">科创板可评分 / 事件</span><b>872 / 26</b><span class="small">其余为预热或隔离</span></div></div>
<div class="warn"><strong>研究结论：回暖不等于点火，平均盈利也不等于稳定有效。</strong><br>创业板 R1c 事件的5/10/20日平均收益均为负。R2子组更值得继续验证，但样本很小。10日持有的混合结果偏弱，20日均值受少数大涨影响。这里是两个宽板风格池回测，尚不是全市场行业回测，也未获得真正事前样本外证明。</div>
<h2>今天的结构</h2><p>补齐历史后，创业板为 R1b 冰点回暖（未确认）；科创板为 R2c 疑似高潮（防追高）。有计算结果，但不是 R2a / R2b 首轮点火候选。</p>__TODAY__
<h2>主回测：原冻结观察规则</h2><p>纳入 R1c / R2a / R2b；同一板块任意观察事件间隔至少20交易日。收益为信号日成员等权篮子的次日开盘至指定日收盘代理，非ETF收益、非实盘收益。</p>__MAIN__
<h2>分别看回暖与点火</h2><p>以下分组沿用主回测的统一去重，不在看到结果后替换主规则。</p>__STAGES__
<h2>R2单独观察：独立诊断</h2><p>仅 R2a / R2b，板块内间隔20日；前面的R1c不再阻挡随后R2。它改变了事件抽样政策，因此与主回测分开报告，不能挑表现更好的表当作策略已验证。</p>__R2__
<h2>与普通时点比较，以及大行情依赖</h2><p>普通时点为同板块所有可评分日的相同持有期、相同成本；窗口存在重叠，不是独立交易组合。删除最好一次仅为稳健性诊断，不是新的交易规则。</p>__BASELINE__
<h2>前700日 / 后300日</h2><p>只检查时段稳定性。规则在2026-10-20冻结，这个历史切分不构成真正事前样本外测试。</p>__PERIOD__
<h2>历史评分时间线</h2><p>CY = 创业板全板；KC = 科创板全板。缺失点保留断线；分数不是收益概率。</p><div class="panel">__SVG__</div>
<h2>逐笔观察事件</h2><div><select id="board"><option value="all">全部板块</option><option value="CY">创业板</option><option value="KC">科创板</option></select><select id="stage"><option value="all">全部状态</option><option>R1c</option><option>R2a</option><option>R2b</option></select></div><div class="scroll"><table><thead><tr><th>信号日</th><th>范围</th><th>状态</th><th>分数</th><th>5日净收益</th><th>10日净收益</th><th>20日净收益</th></tr></thead><tbody id="events"></tbody></table></div>
<h2>覆盖与边界</h2>__COVERAGE__<ul>__CAVEATS__</ul><details><summary>数据来源、交叉检查与复现</summary><p>官方原始日线包：<a href="https://www.tdx.com.cn/products/data/data/vipdoc/shlday.zip">上海</a> / <a href="https://www.tdx.com.cn/products/data/data/vipdoc/szlday.zip">深圳</a>。下载版本为2026-10-20更新。二进制记录32字节，价格÷100，成交额为元，成交量为股。实时归档中5,216只股票的当日收盘价与此源全部一致。</p><p>向量化统计在5个真实日期、2个板块上与原函数核对通过。原引擎分位数函数存在整数位置返回0的展示缺陷，本报告使用标准线性分位数；该字段不参与阶段判定或评分。</p><p>历史库 __HASH__</p><p>执行压力检查：正向一字板入场记现金，负向一字板退出记未解决；ST历史、实际排队、冲击成本仍无法完整还原。</p></details><p class="small">2026-10-20 · Pigskin Signal 2.0 · 可复核研究记录，非收益承诺</p></main><script>
const events=__EVENTS__;const names={CY:'创业板',KC:'科创板'};const fmt=x=>x.status==='ok'?`${x.net_pct>=0?'+':''}${x.net_pct.toFixed(2)}%`:x.status==='unmatured'?'未到期':'隔离';function render(){let b=document.getElementById('board').value,s=document.getElementById('stage').value;document.getElementById('events').innerHTML=events.filter(e=>(b==='all'||e.id===b)&&(s==='all'||e.stage===s)).slice().reverse().map(e=>`<tr><td>${e.date}</td><td>${names[e.id]}</td><td>${e.stage}</td><td>${e.score}</td><td>${fmt(e.hold5)}</td><td>${fmt(e.hold10)}</td><td>${fmt(e.hold20)}</td></tr>`).join('')}document.getElementById('board').onchange=render;document.getElementById('stage').onchange=render;render();</script></body></html>'''
for key,value in {'TODAY':today,'MAIN':main,'STAGES':stages,'R2':r2,'BASELINE':baseline,'PERIOD':period,'SVG':svg,'COVERAGE':coverage,'CAVEATS':''.join('<li>'+html.escape(x)+'</li>' for x in r['caveats']),'HASH':'<br>'.join('<code>'+g+': '+x['sha256']+'</code>' for g,x in r['source_manifest'].items()),'EVENTS':event_data}.items():page=page.replace('__'+key+'__',value)
(O/'backtest1000.html').write_text(page)
readme='''猪皮信号1000交易日回测（2026-10-20）
窗口：2022-08-30至2026-10-20，另44交易日预热。
主规则、收益代理、事件逐条记录与限制见backtest1000.html与backtest1000.json。
运行：python -m pip install numpy pandas exchange-calendars matplotlib
完整原始ZIP在data/shlday.zip、data/szlday.zip；原始文件版本哈希见data/tdx_manifest.json。
已有同版本历史矩阵时运行 python run_backtest.py --matrix，可无需重新下载原始ZIP。
请保留历史矩阵文件data/tdx_1044_session_matrices.npz及data/tdx_manifest.json。
不要用未来更新版本的价格包冒充这次原始输入。当前名单或行业归属不可倒填历史。
'''
(O/'README.txt').write_text(readme)
with zipfile.ZipFile(O/'backtest1000_source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in [R/'run_backtest.py',R/'frozen_engine.py',R/'render_report.py',O/'README.txt',O/'backtest1000.json',O/'daily_features.csv',O/'events.csv',O/'quality.csv',R/'data'/'tdx_manifest.json']:
  arc='data/tdx_manifest.json' if p.name=='tdx_manifest.json' else p.name
  z.write(p,arc)
 print('SOURCE_ZIP',len(z.infolist()))
print('REPORT',O/'backtest1000.html')
